# Campaign Tools Suite (Streamlit Cloud Ready)

This repo contains a multi-page Streamlit app:
- **Campaign Dashboard** — live FEC totals by race (committee IDs).
- **Donor Research** — FEC Schedule A individual contributions.
- **Legislation Tracker** — ProPublica Congress introduced bills.

## Deploy on Streamlit Cloud
1. Create a GitHub repo and upload these files.
2. Go to https://streamlit.io/cloud → **New app** → connect your repo.
3. In **App → Settings → Secrets**, add:
```
FEC_API_KEY = "your_fec_api_key"
PROPUBLICA_API_KEY = "your_propublica_api_key"
```
4. Deploy. Use the sidebar filters on each page.

## Local Run
```bash
pip install -r requirements.txt
export FEC_API_KEY=your_fec_key
export PROPUBLICA_API_KEY=your_pp_key
streamlit run streamlit_app.py
```

## Configure Races
Edit `races_config.csv` and replace the placeholder `committee_id`s with real FEC committee IDs for each candidate.
