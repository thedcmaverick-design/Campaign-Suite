#!/usr/bin/env python3
import os, time, requests, pandas as pd, streamlit as st

st.title("📜 Legislation Tracker (ProPublica)")

API_KEY = st.secrets.get("PROPUBLICA_API_KEY", None) or os.getenv("PROPUBLICA_API_KEY", "")
BASE = "https://api.propublica.org/congress/v1"

with st.sidebar:
    query = st.text_input("Keyword(s)", "health OR education OR housing")
    congress = st.number_input("Congress #", min_value=100, max_value=120, value=118, step=1)
    max_rows = st.slider("Max Results (client-side filter)", 10, 500, 100, 10)

def pp_get(path, params=None):
    if not API_KEY:
        return {"results":[{"bills":[
            {"bill_id":"hr999","title":"Health Equity Improvement Act","short_title":"Health Equity Improvement Act","sponsor_name":"Rep. Doe","introduced_date":"2024-03-12","latest_major_action":"Referred to Committee","congressdotgov_url":"https://congress.gov/"}
        ]}]}
    headers = {"X-API-Key": API_KEY}
    r = requests.get(f"{BASE}/{path}", headers=headers, params=params or {}, timeout=30)
    if r.status_code == 429:
        time.sleep(1.2)
        r = requests.get(f"{BASE}/{path}", headers=headers, params=params or {}, timeout=30)
    r.raise_for_status()
    return r.json()

def run_search():
    js = pp_get(f"{congress}/bills/introduced.json")
    bills = js.get("results", [])[0].get("bills", [])
    terms = [t.strip().lower() for t in query.split("OR")]
    rows = []
    for b in bills:
        text = f"{b.get('title','')} {b.get('short_title','')}".lower()
        if any(t in text for t in terms):
            rows.append({
                "bill_id": b.get("bill_id"),
                "title": b.get("title"),
                "sponsor": b.get("sponsor_name"),
                "introduced": b.get("introduced_date"),
                "latest_action": b.get("latest_major_action"),
                "url": b.get("congressdotgov_url")
            })
    df = pd.DataFrame(rows).head(max_rows)
    return df

if st.button("Search Bills"):
    df = run_search()
    if df is not None and not df.empty:
        st.success(f"Showing {len(df)} bills")
        st.dataframe(df, use_container_width=True)
        st.download_button("Download CSV", df.to_csv(index=False).encode("utf-8"), "bills_snapshot.csv", "text/csv")
    else:
        st.info("No matching bills found. Try different keywords.")
else:
    st.caption("Enter your keywords and click **Search Bills**.")
