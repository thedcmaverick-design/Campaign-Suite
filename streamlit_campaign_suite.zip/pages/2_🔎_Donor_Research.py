#!/usr/bin/env python3
import os, time, requests, pandas as pd, streamlit as st

st.title("🔎 Donor Research (FEC Schedule A)")

API_KEY = st.secrets.get("FEC_API_KEY", None) or os.getenv("FEC_API_KEY", "")
BASE = "https://api.open.fec.gov/v1/schedules/schedule_a/"

with st.sidebar:
    st.write("**Filters**")
    employer = st.text_input("Employer (optional)")
    name = st.text_input("Contributor Name (optional)")
    state = st.text_input("State (2-letter, optional)")
    occupation = st.text_input("Occupation (optional)")
    min_amt = st.number_input("Min Amount", 0, 100000, 0, step=50)
    period = st.selectbox("Two-Year Period", [2024, 2022, 2020], index=0)
    max_pages = st.slider("Max Pages", 1, 20, 5)

def fetch(params, page):
    q = params.copy()
    q["page"] = page
    q["api_key"] = API_KEY
    r = requests.get(BASE, params=q, timeout=30)
    if r.status_code == 429:
        time.sleep(1.2)
        r = requests.get(BASE, params=q, timeout=30)
    r.raise_for_status()
    return r.json()

def run_query():
    rows = []
    if not API_KEY:
        st.warning("No FEC API key found. Showing demo data.")
        return pd.DataFrame([
            {"contributor_name":"Jordan Lee","employer":"Acme Health","occupation":"VP","city":"Arlington","state":"VA","zip":"22201","amount":2800,"date":"2024-05-21","committee":"Friends of Doe","committee_id":"C123"}
        ])

    params = {
        "two_year_transaction_period": period,
        "is_individual": True,
        "per_page": 100,
        "sort_hide_null": False,
        "sort": "-contribution_receipt_amount"
    }
    if employer: params["contributor_employer"] = employer
    if name: params["contributor_name"] = name
    if state: params["contributor_state"] = state
    if occupation: params["contributor_occupation"] = occupation

    for page in range(1, max_pages+1):
        js = fetch(params, page)
        for it in js.get("results", []):
            amt = it.get("contribution_receipt_amount") or 0
            if amt >= min_amt:
                rows.append({
                    "contributor_name": it.get("contributor_name"),
                    "employer": it.get("contributor_employer"),
                    "occupation": it.get("contributor_occupation"),
                    "city": it.get("contributor_city"),
                    "state": it.get("contributor_state"),
                    "zip": it.get("contributor_zip"),
                    "amount": amt,
                    "date": it.get("contribution_receipt_date"),
                    "committee": it.get("committee_name"),
                    "committee_id": it.get("committee_id"),
                })
        if not js.get("pagination") or page >= js["pagination"].get("pages", page):
            break
    return pd.DataFrame(rows)

if st.button("Run Search"):
    df = run_query()
    if df is not None and not df.empty:
        st.success(f"Found {len(df)} records")
        st.dataframe(df, use_container_width=True)
        st.download_button("Download CSV", df.to_csv(index=False).encode("utf-8"), "donor_results.csv", "text/csv")
    else:
        st.info("No results. Try adjusting filters.")
else:
    st.caption("Set your filters in the sidebar, then click **Run Search**.")
