#!/usr/bin/env python3
import streamlit as st

st.set_page_config(page_title="Campaign Tools Suite", layout="wide")
st.title("Campaign Tools Suite")
st.markdown("""
Welcome to your all-in-one political toolkit. Use the pages on the left to:

- **Campaign Dashboard** — view live FEC committee totals by race.
- **Donor Research** — pull Schedule A individual contributions (FEC).
- **Legislation Tracker** — track newly introduced bills (ProPublica).

**Setup (on Streamlit Cloud):**  
Add your API keys in **App → Settings → Secrets**:

```
FEC_API_KEY = "your_fec_api_key"
PROPUBLICA_API_KEY = "your_propublica_api_key"
```

You can also run locally by exporting these environment variables.
""")
